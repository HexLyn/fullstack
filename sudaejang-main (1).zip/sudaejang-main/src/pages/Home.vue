<template>
  <div class="card card-body">
    <h1>Home</h1>
  </div>
</template>

<script>
export default {
  name: 'Home',
};
</script>
